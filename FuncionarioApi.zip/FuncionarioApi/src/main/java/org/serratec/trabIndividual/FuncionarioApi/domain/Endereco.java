package org.serratec.trabIndividual.FuncionarioApi.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


@Embeddable
public class Endereco {
	
	
	@NotBlank(message="Voce deve preencher o nome da rua!")
	@Size(max=50, message="Esse campo em o valor náximo de 50")
	@Column
	private String rua;
	
	@NotBlank(message="Voce deve informar a cidade!")
	@Size(max=30)
	@Column
	private String cidade;
	
	@NotBlank(message="Voce deve informar o estado!")
	@Size(max=30)
	@Column
	private String estado;
	
	@NotBlank
	@Size(min=9, max=9, message="Preencha somente com números!")
	@Column
	private String cep;
	
	

	public Endereco() {
		super();
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		this.rua = rua;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}
	
	
}
